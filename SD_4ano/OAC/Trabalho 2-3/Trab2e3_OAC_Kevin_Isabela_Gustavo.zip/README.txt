→ Extraia os arquivos para uma pasta separada.

→ Abra o arquivo HTML no navegador (de preferência use o Google Chrome).

→ Cole o bloco de binários no campo de entrada (sem espaços excedentes, somente linhas com 32 bits, sem linhas vazias).

→ Clique em enviar para preparar a máquina.

→ Clique em avançar/voltar instrução para executar as instruções passo-a-passo.

→ Para analisar outro bloco de binários, é necessário dar "refresh" na página.
