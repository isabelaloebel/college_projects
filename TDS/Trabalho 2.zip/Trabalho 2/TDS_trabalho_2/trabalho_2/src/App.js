
import Footer from "./componentes/Footer";
import Header from "./componentes/Header";
import Carousel from "./componentes/Carousel";


function App() {
  return (
    <div>
      <Header/>
      <Carousel/>
      <Footer/>
    </div>
  );
}

export default App;
