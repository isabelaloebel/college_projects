import './Carousel.css'
import { useEffect, useState } from "react";

function Carousel() {
    const [data, setData] = useState([]);
  
    useEffect(() => {
      fetch("http://localhost:3000/static/produtos.json")
        .then((response) => response.json())
        .then(setData);
    }, []);
  
    if(!data || !data.length) return null;
  
    return (
        <div className="carousel">
            {data.map((item) => {
                const{id, name, size, price, image} = item;
            
                return(
                    <div className="item" key={id}>
                        <div className="image">
                            <img src={image} alt={name}/>
                        </div> 
                        <div className="info">
                            <span className="name">{name}</span>
                            <span className="price">{size}</span>
                            <span className="name">R${price}</span>

                        </div>
                    </div>
                )
                
            })}
        </div>
    )
    
}

export default Carousel