import { Box } from '@mui/material';

const PropsClientScreen = () => {
    return <Box>Update client</Box>;
};
export default PropsClientScreen;
